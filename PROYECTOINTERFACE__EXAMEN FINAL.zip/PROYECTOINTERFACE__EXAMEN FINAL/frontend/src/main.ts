import 'zone.js';
import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { appConfig } from './app/app.config';

bootstrapApplication(AppComponent, appConfig)
  .catch((err) => {
    console.error('ERROR DE INICIO ANGULAR:', err);
    const root = document.querySelector('app-root');
    if (root) {
      root.innerHTML = `
        <main style="font-family:Arial;padding:32px">
          <h2 style="color:#b42318">No se pudo iniciar Angular</h2>
          <p>Presiona F12 y revisa la pestaña Console.</p>
        </main>
      `;
    }
  });
