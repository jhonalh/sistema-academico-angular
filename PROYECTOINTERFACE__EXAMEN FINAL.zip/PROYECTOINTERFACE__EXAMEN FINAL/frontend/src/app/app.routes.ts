import { Routes } from '@angular/router';
import { LoginComponent } from './pages/login/login.component';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';

export const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'admin',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['ADMIN'] },
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/admin/dashboard/dashboard.component')
            .then(m => m.AdminDashboardComponent)
      },
      {
        path: 'usuarios',
        loadComponent: () =>
          import('./pages/admin/usuarios/usuarios.component')
            .then(m => m.UsuariosComponent)
      },
      {
        path: 'cursos',
        loadComponent: () =>
          import('./pages/admin/cursos/cursos.component')
            .then(m => m.CursosComponent)
      },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
    ]
  },
  {
    path: 'profesor',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['PROFESOR'] },
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/profesor/dashboard/dashboard.component')
            .then(m => m.ProfesorDashboardComponent)
      },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
    ]
  },
  {
    path: 'estudiante',
    canActivate: [authGuard, roleGuard],
    data: { roles: ['ESTUDIANTE'] },
    children: [
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./pages/estudiante/dashboard/dashboard.component')
            .then(m => m.EstudianteDashboardComponent)
      },
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' }
    ]
  },
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: '**', redirectTo: 'login' }
];
