import { inject } from '@angular/core';
import { CanActivateFn, ActivatedRouteSnapshot, Router } from '@angular/router';
import { AuthService } from '../services/auth.service';

export const roleGuard: CanActivateFn = (route: ActivatedRouteSnapshot) => {
  const auth = inject(AuthService);
  const router = inject(Router);
  const allowed = route.data['roles'] as string[] | undefined;

  if (!auth.isAuthenticated()) return router.createUrlTree(['/login']);
  if (!allowed || allowed.includes(auth.role() ?? '')) return true;

  const role = auth.role();
  if (role === 'ADMIN') return router.createUrlTree(['/admin/dashboard']);
  if (role === 'PROFESOR') return router.createUrlTree(['/profesor/dashboard']);
  return router.createUrlTree(['/estudiante/dashboard']);
};
