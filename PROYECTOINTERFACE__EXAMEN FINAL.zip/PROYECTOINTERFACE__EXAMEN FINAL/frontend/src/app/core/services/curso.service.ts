import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export interface CursoItem {
  id: number;
  nombre: string;
  descripcion: string;
  idSeccion: number;
  estado: boolean;
}

export interface CursoPayload {
  nombre: string;
  descripcion: string;
  idSeccion: number;
  estado: boolean;
}

@Injectable({ providedIn: 'root' })
export class CursoService {

  private readonly url = `${environment.apiUrl}/cursos`;

  constructor(private http: HttpClient) {}

  listar() {
    return this.http.get<CursoItem[]>(this.url);
  }

  crear(curso: CursoPayload) {
    return this.http.post<CursoItem>(this.url, curso);
  }

  actualizar(id: number, curso: CursoPayload) {
    return this.http.put<CursoItem>(`${this.url}/${id}`, curso);
  }

  eliminar(id: number) {
    return this.http.delete<void>(`${this.url}/${id}`);
  }
}
