import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';
import { environment } from '../../../environments/environment';

export interface LoginResponse {
  token: string;
  rol: 'ADMIN' | 'PROFESOR' | 'ESTUDIANTE';
  nombreCompleto: string;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN = 'token';
  private readonly ROLE = 'rol';
  private readonly NAME = 'nombre';

  constructor(private http: HttpClient, private router: Router) {}

  login(dni: string, password: string) {
    return this.http.post<LoginResponse>(`${environment.apiUrl}/auth/login`, { dni, password })
      .pipe(tap(res => {
        localStorage.setItem(this.TOKEN, res.token);
        localStorage.setItem(this.ROLE, res.rol);
        localStorage.setItem(this.NAME, res.nombreCompleto);
      }));
  }

  token(): string | null { return localStorage.getItem(this.TOKEN); }
  role(): string | null { return localStorage.getItem(this.ROLE); }

  isAuthenticated(): boolean {
    const token = this.token();
    if (!token) return false;

    try {
      const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
      const exp = Number(payload.exp);
      if (!exp || Date.now() >= exp * 1000) {
        this.clearSession();
        return false;
      }
      return true;
    } catch {
      this.clearSession();
      return false;
    }
  }

  clearSession(): void {
    localStorage.removeItem(this.TOKEN);
    localStorage.removeItem(this.ROLE);
    localStorage.removeItem(this.NAME);
  }

  logout(): void {
    this.clearSession();
    this.router.navigateByUrl('/login', { replaceUrl: true });
  }

  redirectByRole(): void {
    const role = this.role();
    if (role === 'ADMIN') this.router.navigateByUrl('/admin/usuarios', { replaceUrl: true });
    else if (role === 'PROFESOR') this.router.navigateByUrl('/profesor/dashboard', { replaceUrl: true });
    else if (role === 'ESTUDIANTE') this.router.navigateByUrl('/estudiante/dashboard', { replaceUrl: true });
    else this.logout();
  }
}
