import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export interface UsuarioPayload {
  primerNombre: string;
  segundoNombre: string;
  apellido: string;
  dni: string;
  email: string;
  password: string;
  rol: string;
  telefonos: string[];
}

export interface UsuarioItem {
  id: number;
  dni: string;
  primerNombre: string;
  segundoNombre: string;
  apellido: string;
  email: string;
  estado: boolean;
  rol: string;
  telefonos: string[];
}

@Injectable({ providedIn: 'root' })
export class UsuarioService {
  constructor(private http: HttpClient) {}

  listar() {
    return this.http.get<UsuarioItem[]>(`${environment.apiUrl}/usuarios`);
  }

  crear(usuario: UsuarioPayload) {
    return this.http.post<UsuarioItem>(`${environment.apiUrl}/usuarios`, usuario);
  }

  actualizar(id: number, usuario: UsuarioPayload) {
    return this.http.put<UsuarioItem>(`${environment.apiUrl}/usuarios/${id}`, usuario);
  }

  eliminar(id: number) {
    return this.http.delete(`${environment.apiUrl}/usuarios/${id}`);
  }
}
