import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormArray, FormBuilder, FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { LayoutComponent } from '../../../shared/layout/layout.component';
import { UsuarioItem, UsuarioPayload, UsuarioService } from '../../../core/services/usuario.service';

@Component({
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, LayoutComponent],
  templateUrl: './usuarios.component.html',
  styleUrl: './usuarios.component.css'
})
export class UsuariosComponent implements OnInit {
  usuarios: UsuarioItem[] = [];
  mensaje = '';
  error = '';
  editandoId: number | null = null;
  guardando = false;

  form = this.fb.nonNullable.group({
    primerNombre: ['', [
      Validators.required,
      Validators.pattern(/^[A-Za-zÁÉÍÓÚáéíóúÑñÜü ]{2,100}$/)
    ]],
    segundoNombre: ['', [
      Validators.required,
      Validators.pattern(/^[A-Za-zÁÉÍÓÚáéíóúÑñÜü ]{2,100}$/)
    ]],
    apellido: ['', [
      Validators.pattern(/^$|^[A-Za-zÁÉÍÓÚáéíóúÑñÜü ]{2,100}$/)
    ]],
    dni: ['', [Validators.required, Validators.pattern(/^\d{8}$/)]],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.pattern(/^\d{6}$/)]],
    rol: ['ESTUDIANTE', Validators.required],
    telefonos: this.fb.array<FormControl<string>>([
      this.fb.nonNullable.control('', [Validators.required, Validators.pattern(/^\d{9}$/)])
    ])
  });

  constructor(private fb: FormBuilder, private service: UsuarioService) {}

  get telefonos(): FormArray<FormControl<string>> {
    return this.form.controls.telefonos;
  }

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.error = '';
    this.service.listar().subscribe({
      next: data => {
        this.usuarios = [...data].sort((a, b) => {
          if (a.rol === 'ADMIN' && b.rol !== 'ADMIN') return -1;
          if (a.rol !== 'ADMIN' && b.rol === 'ADMIN') return 1;
          return a.id - b.id;
        });
      },
      error: err => {
        this.error = err?.error?.mensaje ?? 'No se pudieron cargar los usuarios';
      }
    });
  }

  agregarTelefono(): void {
    if (this.telefonos.length >= 2) {
      this.error = 'Solo puedes registrar hasta 2 teléfonos por usuario.';
      return;
    }

    this.error = '';
    this.telefonos.push(
      this.fb.nonNullable.control('', [Validators.required, Validators.pattern(/^\d{9}$/)])
    );
  }

  quitarTelefono(i: number): void {
    if (this.telefonos.length > 1) {
      this.telefonos.removeAt(i);
    }
  }

  editar(u: UsuarioItem): void {
    this.editandoId = u.id;
    this.mensaje = '';
    this.error = '';

    while (this.telefonos.length > 0) {
      this.telefonos.removeAt(0);
    }

    for (const numero of u.telefonos) {
      this.telefonos.push(
        this.fb.nonNullable.control(numero, [Validators.required, Validators.pattern(/^\d{9}$/)])
      );
    }

    if (this.telefonos.length === 0) {
      this.agregarTelefono();
    }

    this.form.patchValue({
      primerNombre: u.primerNombre,
      segundoNombre: u.segundoNombre,
      apellido: u.apellido ?? '',
      dni: u.dni,
      email: u.email,
      password: '',
      rol: u.rol
    });

    this.form.controls.password.clearValidators();
    this.form.controls.password.addValidators(
      Validators.pattern(/^$|^[A-Za-z0-9]{6,30}$/)
    );
    this.form.controls.password.updateValueAndValidity();
  }

  cancelarEdicion(): void {
    this.editandoId = null;
    this.restablecerFormulario();
  }

  guardar(): void {
    this.mensaje = '';
    this.error = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    const eraNuevo = this.editandoId === null;
    const idEditando = this.editandoId;
    const payload = this.form.getRawValue() as UsuarioPayload;

    const duplicado = this.validarDuplicadosLocales(payload, idEditando);
    if (duplicado) {
      this.error = duplicado;
      return;
    }

    this.guardando = true;

    const operacion = eraNuevo
      ? this.service.crear(payload)
      : this.service.actualizar(idEditando!, payload);

    operacion.subscribe({
      next: () => {
        this.mensaje = eraNuevo
          ? 'Usuario registrado correctamente'
          : 'Usuario actualizado correctamente';

        this.editandoId = null;
        this.guardando = false;
        this.restablecerFormulario();

        // Se vuelve a consultar al backend para mostrar exactamente lo persistido en MySQL.
        this.cargar();
      },
      error: err => {
        this.guardando = false;
        this.error = err?.error?.mensaje ?? 'No se pudo guardar el usuario';
      }
    });
  }

  eliminar(id: number): void {
    if (!confirm('¿Seguro que deseas eliminar este usuario?')) {
      return;
    }

    this.service.eliminar(id).subscribe({
      next: () => {
        this.mensaje = 'Usuario eliminado correctamente';
        // Verifica el borrado volviendo a consultar MySQL a través del backend.
        this.cargar();
      },
      error: err => {
        this.error = err?.error?.mensaje ?? 'No se pudo eliminar el usuario';
      }
    });
  }

  nombreCompleto(u: UsuarioItem): string {
    return [u.primerNombre, u.segundoNombre, u.apellido]
      .filter(valor => !!valor && valor.trim().length > 0)
      .join(' ');
  }


  private validarDuplicadosLocales(
    payload: UsuarioPayload,
    idActual: number | null
  ): string | null {

    const email = payload.email.trim().toLowerCase();
    const otros = this.usuarios.filter(u => u.id !== idActual);

    if (otros.some(u => u.dni === payload.dni)) {
      return 'El DNI ya está registrado. Usa un DNI diferente.';
    }

    if (otros.some(u => u.email.trim().toLowerCase() === email)) {
      return 'El correo electrónico ya está en uso. Usa otro correo.';
    }

    const telefonos = payload.telefonos.filter(t => !!t);

    if (new Set(telefonos).size !== telefonos.length) {
      return 'No puedes registrar el mismo teléfono dos veces para el mismo usuario.';
    }

    for (const telefono of telefonos) {
      if (otros.some(u => u.telefonos.includes(telefono))) {
        return `El teléfono ${telefono} ya está registrado en otra cuenta.`;
      }
    }

    return null;
  }

  private restablecerFormulario(): void {
    while (this.telefonos.length > 0) {
      this.telefonos.removeAt(0);
    }
    this.agregarTelefono();

    this.form.controls.password.setValidators([
      Validators.required,
      Validators.pattern(/^\d{6}$/)
    ]);

    this.form.reset({
      primerNombre: '',
      segundoNombre: '',
      apellido: '',
      dni: '',
      email: '',
      password: '',
      rol: 'ESTUDIANTE',
      telefonos: ['']
    });

    this.form.controls.password.updateValueAndValidity();
  }
}
