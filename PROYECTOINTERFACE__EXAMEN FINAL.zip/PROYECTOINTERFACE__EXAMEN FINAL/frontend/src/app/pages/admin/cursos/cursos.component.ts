import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LayoutComponent } from '../../../shared/layout/layout.component';
import { CursoItem, CursoPayload, CursoService } from '../../../core/services/curso.service';

@Component({
  standalone: true,
  imports: [CommonModule, FormsModule, LayoutComponent],
  templateUrl: './cursos.component.html',
  styleUrl: './cursos.component.css'
})
export class CursosComponent implements OnInit {

  cursos: CursoItem[] = [];
  curso: CursoPayload = this.vacio();
  editandoId: number | null = null;
  mensaje = '';
  error = '';
  guardando = false;

  constructor(private service: CursoService) {}

  ngOnInit(): void {
    this.cargar();
  }

  cargar(): void {
    this.error = '';

    this.service.listar().subscribe({
      next: (data) => {
        this.cursos = [...data].sort((a, b) => a.id - b.id);
      },
      error: (err) => {
        this.error = err?.error?.mensaje ?? 'No se pudieron cargar los cursos';
      }
    });
  }

  editar(c: CursoItem): void {
    this.editandoId = c.id;
    this.mensaje = '';
    this.error = '';

    this.curso = {
      nombre: c.nombre ?? '',
      descripcion: c.descripcion ?? '',
      idSeccion: Number(c.idSeccion),
      estado: c.estado ?? true
    };

    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  guardar(): void {
    this.mensaje = '';
    this.error = '';

    const nombre = (this.curso.nombre ?? '').trim();
    const idSeccion = Number(this.curso.idSeccion);

    if (!nombre) {
      this.error = 'El nombre del curso es obligatorio';
      return;
    }

    if (!Number.isInteger(idSeccion) || idSeccion <= 0) {
      this.error = 'La sección debe ser un número mayor que 0';
      return;
    }

    const payload: CursoPayload = {
      nombre,
      descripcion: (this.curso.descripcion ?? '').trim(),
      idSeccion,
      estado: this.curso.estado !== false
    };

    const id = this.editandoId;
    const esNuevo = id === null;
    this.guardando = true;

    const peticion = esNuevo
      ? this.service.crear(payload)
      : this.service.actualizar(id!, payload);

    peticion.subscribe({
      next: (guardado) => {
        if (esNuevo) {
          this.cursos = [...this.cursos, guardado]
            .sort((a, b) => a.id - b.id);
          this.mensaje = 'Curso creado correctamente';
        } else {
          this.cursos = this.cursos.map(c =>
            c.id === guardado.id ? guardado : c
          );
          this.mensaje = 'Curso actualizado correctamente';
        }

        this.guardando = false;
        this.cancelar(false);
      },
      error: (err) => {
        this.guardando = false;
        this.error = err?.error?.mensaje ?? 'No se pudo guardar el curso';
      }
    });
  }

  cancelar(limpiarMensaje = true): void {
    this.editandoId = null;
    this.curso = this.vacio();

    if (limpiarMensaje) {
      this.mensaje = '';
      this.error = '';
    }
  }

  eliminar(id: number): void {
    if (!confirm('¿Seguro que deseas eliminar este curso?')) {
      return;
    }

    this.service.eliminar(id).subscribe({
      next: () => {
        this.cursos = this.cursos.filter(c => c.id !== id);
        this.mensaje = 'Curso eliminado correctamente';
        this.error = '';
      },
      error: (err) => {
        this.error = err?.error?.mensaje ?? 'No se pudo eliminar el curso';
      }
    });
  }

  private vacio(): CursoPayload {
    return {
      nombre: '',
      descripcion: '',
      idSeccion: 1,
      estado: true
    };
  }
}
