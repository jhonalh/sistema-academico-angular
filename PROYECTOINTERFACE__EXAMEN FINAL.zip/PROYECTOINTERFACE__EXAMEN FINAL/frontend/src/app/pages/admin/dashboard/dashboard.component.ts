import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { forkJoin } from 'rxjs';

import { LayoutComponent } from '../../../shared/layout/layout.component';
import { CursoItem, CursoService } from '../../../core/services/curso.service';
import { UsuarioItem, UsuarioService } from '../../../core/services/usuario.service';

@Component({
  standalone: true,
  imports: [CommonModule, RouterLink, LayoutComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class AdminDashboardComponent implements OnInit {

  usuarios: UsuarioItem[] = [];
  cursos: CursoItem[] = [];

  totalUsuarios = 0;
  totalAdmins = 0;
  totalProfesores = 0;
  totalEstudiantes = 0;
  totalCursos = 0;
  cursosActivos = 0;

  cargando = true;
  error = '';

  constructor(
    private usuarioService: UsuarioService,
    private cursoService: CursoService
  ) {}

  ngOnInit(): void {
    this.cargarDashboard();
  }

  cargarDashboard(): void {
    this.cargando = true;
    this.error = '';

    forkJoin({
      usuarios: this.usuarioService.listar(),
      cursos: this.cursoService.listar()
    }).subscribe({
      next: ({ usuarios, cursos }) => {
        this.usuarios = usuarios;
        this.cursos = cursos;

        this.totalUsuarios = usuarios.length;
        this.totalAdmins = usuarios.filter(u => u.rol === 'ADMIN').length;
        this.totalProfesores = usuarios.filter(u => u.rol === 'PROFESOR').length;
        this.totalEstudiantes = usuarios.filter(u => u.rol === 'ESTUDIANTE').length;

        this.totalCursos = cursos.length;
        this.cursosActivos = cursos.filter(c => c.estado !== false).length;

        this.cargando = false;
      },
      error: (err) => {
        this.cargando = false;
        this.error = err?.error?.mensaje ?? 'No se pudieron cargar los datos del dashboard.';
      }
    });
  }

  get usuariosRecientes(): UsuarioItem[] {
    return [...this.usuarios].sort((a, b) => b.id - a.id).slice(0, 5);
  }

  get cursosRecientes(): CursoItem[] {
    return [...this.cursos].sort((a, b) => b.id - a.id).slice(0, 5);
  }

  nombreCompleto(u: UsuarioItem): string {
    return [u.primerNombre, u.segundoNombre, u.apellido]
      .filter(v => !!v && v.trim().length > 0)
      .join(' ');
  }
}
