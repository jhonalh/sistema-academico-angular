import { CommonModule } from '@angular/common';
import { Component, inject } from '@angular/core';
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);

  mensaje = '';
  cargando = false;

  readonly form = this.fb.nonNullable.group({
    dni: ['', [Validators.required, Validators.pattern(/^\d{8}$/)]],
    password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(30)]]
  });

  ingresar(): void {
    this.mensaje = '';

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.cargando = true;
    const { dni, password } = this.form.getRawValue();

    this.auth.login(dni, password).subscribe({
      next: () => {
        this.cargando = false;
        this.auth.redirectByRole();
      },
      error: (err) => {
        this.cargando = false;
        this.mensaje = err?.error?.mensaje ?? 'No se pudo iniciar sesión';
      }
    });
  }
}
