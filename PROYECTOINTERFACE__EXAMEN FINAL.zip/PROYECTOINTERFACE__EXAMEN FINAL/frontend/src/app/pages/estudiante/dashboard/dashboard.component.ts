import { Component } from '@angular/core';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  standalone: true,
  template: `
    <main class="page">
      <div class="top"><h1>Panel del estudiante</h1><button (click)="auth.logout()">Cerrar sesión</button></div>
      <p>Aquí se mostrarán los cursos matriculados y las calificaciones.</p>
    </main>
  `,
  styles:[`.page{padding:32px}.top{display:flex;justify-content:space-between;align-items:center}`]
})
export class EstudianteDashboardComponent {
  constructor(public auth: AuthService) {}
}
