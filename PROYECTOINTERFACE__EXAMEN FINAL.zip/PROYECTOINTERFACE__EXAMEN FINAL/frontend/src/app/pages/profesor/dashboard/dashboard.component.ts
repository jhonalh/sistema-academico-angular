import { Component } from '@angular/core';
import { AuthService } from '../../../core/services/auth.service';

@Component({
  standalone: true,
  template: `
    <main class="page">
      <div class="top"><h1>Panel del profesor</h1><button (click)="auth.logout()">Cerrar sesión</button></div>
      <p>Aquí se mostrarán los cursos asignados, alumnos y notas.</p>
    </main>
  `,
  styles:[`.page{padding:32px}.top{display:flex;justify-content:space-between;align-items:center}`]
})
export class ProfesorDashboardComponent {
  constructor(public auth: AuthService) {}
}
