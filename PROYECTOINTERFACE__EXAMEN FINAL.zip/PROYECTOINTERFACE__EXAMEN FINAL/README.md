# Sistema Académico SPA — Angular + Spring Boot + MySQL

Proyecto académico alineado con la rúbrica proporcionada.

## Cumplimiento principal

- SPA desarrollada en Angular.
- Login con JWT.
- Rutas públicas y privadas.
- `AuthGuard` para impedir acceso sin autenticación.
- `RoleGuard` para ADMIN, PROFESOR y ESTUDIANTE.
- Carga dinámica mediante `loadComponent`.
- `HttpClient` + interceptor JWT.
- CRUD de usuarios: listar, crear, editar y eliminar.
- CRUD de cursos: listar, crear, editar y eliminar.
- MySQL como base de datos, administrable con MySQL Workbench.
- Teléfonos en tabla independiente `telefono_usuario`.
- Validaciones duplicadas en frontend y backend.

## Validaciones pedidas

- DNI: exactamente 8 dígitos.
- DNI único.
- Correo válido y único.
- Primer y segundo nombre obligatorios.
- Contraseña: exactamente 6 dígitos en alta.
- Contraseña almacenada con BCrypt.
- Varios teléfonos por usuario.
- Cada teléfono: exactamente 9 dígitos.
- No se permite repetir teléfonos.
- Si un usuario se edita, puede mantener la contraseña dejando el campo vacío.

## Seguridad de navegación

Al cerrar sesión:
1. se elimina el JWT;
2. se elimina el rol y el nombre del almacenamiento local;
3. Angular redirige a `/login` usando `replaceUrl`;
4. si el navegador intenta recuperar una ruta privada con Atrás/Adelante, `AuthGuard` vuelve a validar el token;
5. el token también se valida por fecha de expiración;
6. si la API responde `401`, el interceptor cierra la sesión automáticamente.

## Credenciales iniciales

El backend crea automáticamente un administrador si no existe:

```text
DNI: `76638892`
Contraseña: `admin123`
```

Cambiar estas credenciales para una entrega real si el docente lo solicita.

## Base de datos

1. Abrir MySQL Workbench.
2. Ejecutar `database/sistema_academico.sql`.
3. La base creada se llama:

```text
sistema_academico
```

Tablas:

- rol
- usuario
- telefono_usuario
- docente
- alumno
- seccion
- curso
- asignacion_curso
- matricula
- nota_curso

## Configurar Spring Boot

Abrir:

```text
backend/src/main/resources/application.properties
```

Cambiar:

```properties
spring.datasource.username=root
spring.datasource.password=789456
app.jwt.secret=UNA_CLAVE_LARGA_DE_32_CARACTERES_O_MAS
```

Ejemplo de clave JWT para pruebas:

```text
SistemaAcademicoJWT2026ClaveSeguraDemo
```

## Ejecutar backend

```bash
cd backend
mvn spring-boot:run
```

Backend:

```text
http://localhost:8080
```

## Ejecutar Angular

```bash
cd frontend
npm install
npm start
```

Frontend:

```text
http://localhost:4200
```

## API REST

### Autenticación

```text
POST /api/auth/login
```

### Usuarios

```text
GET    /api/usuarios
POST   /api/usuarios
PUT    /api/usuarios/{id}
DELETE /api/usuarios/{id}
```

### Cursos

```text
GET    /api/cursos
POST   /api/cursos
PUT    /api/cursos/{id}
DELETE /api/cursos/{id}
```

## Rutas Angular

Pública:

```text
/login
```

Protegidas:

```text
/admin/dashboard
/admin/usuarios
/admin/cursos
/profesor/dashboard
/estudiante/dashboard
```

## PDF de presentación

Usar `docs/GUIA_PDF.md` como base. Debe incluir:

- explicación de rutas;
- AuthGuard y RoleGuard;
- autenticación JWT;
- servicios REST;
- evidencias de pruebas funcionales;
- enlace GitHub;
- instrucciones del README.


## Si npm muestra ERESOLVE

La versión corregida usa paquetes Angular fijados en versiones compatibles.

Desde la carpeta `frontend` ejecutar:

```powershell
Remove-Item -Recurse -Force node_modules -ErrorAction SilentlyContinue
Remove-Item -Force package-lock.json -ErrorAction SilentlyContinue
npm cache clean --force
npm install
npm start
```


## Iniciar todo desde Visual Studio Code

El proyecto incluye `.vscode/tasks.json`.

1. Abrir la carpeta `PROYECTOINTERFACE` en VS Code.
2. Presionar `Ctrl + Shift + P`.
3. Ejecutar `Tasks: Run Task`.
4. Seleccionar `Iniciar PROYECTOINTERFACE`.

VS Code iniciará Spring Boot y Angular en terminales separadas.

- Backend: `http://localhost:8080`
- Frontend: `http://localhost:4200`


## Inicio con una sola terminal

Desde la carpeta raíz `PROYECTOINTERFACE`:

Primera vez:

```powershell
npm install
npm start
```

Las siguientes veces:

```powershell
npm start
```

Este comando inicia Angular en `http://localhost:4200` y Spring Boot en `http://localhost:8080`.
MySQL debe estar iniciado y la base `sistema_academico` debe existir.


### Importante sobre `frontend/node_modules`

La tarea raíz ahora ejecuta automáticamente `npm --prefix frontend install` antes de `ng serve`.
Por eso, después de descomprimir o reemplazar el proyecto, `npm start` puede tardar más la primera vez.


## Administrador predeterminado actualizado

Al iniciar el backend, el sistema garantiza un administrador predeterminado:

- Nombre completo: `Admin Sistema`
- DNI: `76638892`
- Correo: `programadorlh@gmail.com`
- Teléfono: `933610705`
- Rol: `ADMIN`

La contraseña se almacena con BCrypt y **nunca se devuelve en las respuestas REST ni se muestra en la tabla de usuarios**.

Si todavía existe el administrador de demostración anterior con DNI `12345678`, la aplicación lo migra automáticamente a los nuevos datos cuando arranca.


## Varios teléfonos por usuario

Los teléfonos **no se guardan dentro de la tabla `usuario`**. Se almacenan en la tabla independiente:

```text
telefono_usuario
```

Relación:

```text
usuario (1) -------- (N) telefono_usuario
```

Ejemplo: si Juan Pérez tiene dos números, en `usuario` existe una sola fila para Juan Pérez y en `telefono_usuario` existen dos filas con el mismo `id_usuario`.

La pantalla **Editar usuario** carga todos los teléfonos existentes y permite agregar más con el botón `+ Agregar teléfono`. Al guardar, el backend actualiza la colección completa en `telefono_usuario`.


## Regla de teléfonos actualizada

Cada usuario se guarda una sola vez en la tabla `usuario`.

Sus teléfonos se guardan aparte en `telefono_usuario`.

Ejemplo:

```text
usuario
id_usuario | dni      | nombre
15         | 44556677 | Juan Perez
```

```text
telefono_usuario
id_telefono | id_usuario | numero
31          | 15         | 933111222
32          | 15         | 944333555
```

La pantalla Registrar/Editar usuario permite como máximo **2 teléfonos por usuario**.


## Edición de cursos corregida

La pantalla Cursos permite:
- crear cursos;
- seleccionar `Editar`;
- modificar nombre, descripción, sección y estado;
- guardar los cambios con `PUT /api/cursos/{id}`;
- actualizar la fila en pantalla inmediatamente;
- persistir los cambios en la tabla `curso` de MySQL.


## Persistencia CRUD de usuarios verificada

Crear, editar y eliminar usuarios persiste en MySQL.
Los datos generales se guardan en `usuario` y los 1 o 2 teléfonos en `telefono_usuario`.
Después de cada operación, Angular vuelve a consultar la API para mostrar exactamente lo que quedó almacenado.
La contraseña nunca forma parte de `UsuarioResponse`.


## Dashboard administrativo con datos reales

El Dashboard del administrador consulta la API y muestra datos reales de MySQL:
- total de usuarios;
- administradores, profesores y estudiantes;
- total de cursos y cursos activos;
- últimos usuarios registrados;
- últimos cursos registrados;
- estado de seguridad JWT + Guards.

Los valores se actualizan cada vez que se abre o recarga el Dashboard.


## Validaciones completas de usuarios

La pantalla Usuarios valida nombres, DNI, correo, contraseña y teléfonos.
DNI, correo y teléfonos son únicos. Si se intenta reutilizar uno, la aplicación
muestra una advertencia indicando que ya está registrado o en uso.
Las mismas reglas se validan nuevamente en Spring Boot.


## Diseño visual v20

La interfaz del administrador fue rediseñada para coincidir con las maquetas visuales aprobadas:
- sidebar azul oscuro con iconos y navegación activa;
- header blanco con botón rojo de cerrar sesión;
- dashboard con tarjetas métricas, usuarios recientes, cursos recientes y seguridad;
- gestión de usuarios con formulario lateral y tabla moderna;
- gestión de cursos con el mismo lenguaje visual;
- favicon y título Angular en la pestaña del navegador.

No se modificó la lógica del backend, JWT, guards ni persistencia MySQL.
