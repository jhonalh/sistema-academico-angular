USE sistema_academico;

-- 1. Lista de usuarios, contraseña omitida intencionalmente.
SELECT
    u.id_usuario,
    u.dni,
    CONCAT_WS(
        ' ',
        NULLIF(u.primer_nombre, ''),
        NULLIF(u.segundo_nombre, ''),
        NULLIF(u.apellido, '')
    ) AS nombre_completo,
    u.email,
    r.nombre_rol AS rol,
    u.estado
FROM usuario u
JOIN rol r ON r.id_rol = u.id_rol
ORDER BY u.id_usuario;

-- 2. Teléfonos guardados en la tabla independiente.
SELECT
    t.id_telefono,
    t.id_usuario,
    u.dni,
    t.numero
FROM telefono_usuario t
JOIN usuario u ON u.id_usuario = t.id_usuario
ORDER BY t.id_usuario, t.id_telefono;

-- 3. Vista combinada para verificar edición de nombre/correo/teléfonos.
SELECT
    u.id_usuario,
    u.dni,
    CONCAT_WS(
        ' ',
        NULLIF(u.primer_nombre, ''),
        NULLIF(u.segundo_nombre, ''),
        NULLIF(u.apellido, '')
    ) AS nombre_completo,
    u.email,
    r.nombre_rol AS rol,
    GROUP_CONCAT(t.numero ORDER BY t.id_telefono SEPARATOR ', ') AS telefonos
FROM usuario u
JOIN rol r ON r.id_rol = u.id_rol
LEFT JOIN telefono_usuario t ON t.id_usuario = u.id_usuario
GROUP BY
    u.id_usuario,
    u.dni,
    u.primer_nombre,
    u.segundo_nombre,
    u.apellido,
    u.email,
    r.nombre_rol
ORDER BY u.id_usuario;
