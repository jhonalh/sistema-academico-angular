USE sistema_academico;

SELECT
    u.id_usuario,
    u.dni,
    CONCAT_WS(' ', NULLIF(u.primer_nombre, ''), NULLIF(u.segundo_nombre, ''), NULLIF(u.apellido, '')) AS nombre_completo,
    u.email,
    r.nombre_rol AS rol,
    GROUP_CONCAT(t.numero ORDER BY t.id_telefono SEPARATOR ', ') AS telefonos
FROM usuario u
JOIN rol r ON r.id_rol = u.id_rol
LEFT JOIN telefono_usuario t ON t.id_usuario = u.id_usuario
WHERE u.dni = '76638892'
GROUP BY u.id_usuario, u.dni, u.primer_nombre, u.segundo_nombre, u.apellido, u.email, r.nombre_rol;
