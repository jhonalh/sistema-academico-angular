USE sistema_academico;

-- Este archivo es solo un ejemplo de prueba.
-- Primero crea "Juan Perez" desde la aplicación y agrega dos teléfonos.
-- Luego usa esta consulta para comprobar que los teléfonos se guardaron
-- en la tabla independiente telefono_usuario.

SELECT
    u.id_usuario,
    u.dni,
    CONCAT_WS(' ', u.primer_nombre, u.segundo_nombre, u.apellido) AS nombre_completo,
    t.id_telefono,
    t.numero
FROM usuario u
JOIN telefono_usuario t
    ON t.id_usuario = u.id_usuario
WHERE CONCAT_WS(' ', u.primer_nombre, u.segundo_nombre, u.apellido) LIKE '%Juan%Perez%'
ORDER BY u.id_usuario, t.id_telefono;
