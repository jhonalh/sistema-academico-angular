DROP DATABASE IF EXISTS sistema_academico;
CREATE DATABASE sistema_academico CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE sistema_academico;

CREATE TABLE rol (
    id_rol INT AUTO_INCREMENT PRIMARY KEY,
    nombre_rol VARCHAR(50) NOT NULL UNIQUE,
    descripcion TEXT
);

CREATE TABLE usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    dni VARCHAR(8) NOT NULL UNIQUE,
    primer_nombre VARCHAR(100) NOT NULL,
    segundo_nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    estado TINYINT(1) NOT NULL DEFAULT 1,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    id_rol INT NOT NULL,
    CONSTRAINT fk_usuario_rol FOREIGN KEY (id_rol) REFERENCES rol(id_rol)
);

CREATE TABLE telefono_usuario (
    id_telefono INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    numero VARCHAR(9) NOT NULL,
    CONSTRAINT uq_telefono_numero UNIQUE (numero),
    CONSTRAINT fk_telefono_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuario(id_usuario) ON DELETE CASCADE
);

CREATE TABLE docente (
    id_docente INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL UNIQUE,
    especialidad VARCHAR(150),
    grado_academico VARCHAR(100),
    CONSTRAINT fk_docente_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuario(id_usuario)
);

CREATE TABLE alumno (
    id_alumno INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL UNIQUE,
    dni_apoderado VARCHAR(8),
    fecha_nacimiento DATE,
    CONSTRAINT fk_alumno_usuario FOREIGN KEY (id_usuario)
        REFERENCES usuario(id_usuario)
);

CREATE TABLE seccion (
    id_seccion INT AUTO_INCREMENT PRIMARY KEY,
    nombre_seccion VARCHAR(50) NOT NULL,
    periodo_academico VARCHAR(20) NOT NULL,
    capacidad_maxima INT NOT NULL,
    estado TINYINT(1) NOT NULL DEFAULT 1
);

CREATE TABLE curso (
    id_curso INT AUTO_INCREMENT PRIMARY KEY,
    id_seccion INT NOT NULL,
    nombre VARCHAR(150) NOT NULL,
    descripcion TEXT,
    estado TINYINT(1) NOT NULL DEFAULT 1,
    fecha_creacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_curso_seccion FOREIGN KEY (id_seccion)
        REFERENCES seccion(id_seccion)
);

CREATE TABLE asignacion_curso (
    id_asignacion INT AUTO_INCREMENT PRIMARY KEY,
    id_docente INT NOT NULL,
    id_curso INT NOT NULL,
    estado TINYINT(1) NOT NULL DEFAULT 1,
    fecha_asignacion TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_asignacion_docente FOREIGN KEY (id_docente)
        REFERENCES docente(id_docente),
    CONSTRAINT fk_asignacion_curso FOREIGN KEY (id_curso)
        REFERENCES curso(id_curso)
);

CREATE TABLE matricula (
    id_matricula INT AUTO_INCREMENT PRIMARY KEY,
    id_alumno INT NOT NULL,
    id_seccion INT NOT NULL,
    fecha_matricula DATE NOT NULL,
    estado TINYINT(1) NOT NULL DEFAULT 1,
    CONSTRAINT fk_matricula_alumno FOREIGN KEY (id_alumno)
        REFERENCES alumno(id_alumno),
    CONSTRAINT fk_matricula_seccion FOREIGN KEY (id_seccion)
        REFERENCES seccion(id_seccion)
);

CREATE TABLE nota_curso (
    id_nota INT AUTO_INCREMENT PRIMARY KEY,
    id_curso INT NOT NULL,
    id_alumno INT NOT NULL,
    nombre_evaluacion VARCHAR(100) NOT NULL,
    calificacion DECIMAL(5,2),
    ponderacion DECIMAL(5,2),
    fecha_registro TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_nota_curso FOREIGN KEY (id_curso)
        REFERENCES curso(id_curso),
    CONSTRAINT fk_nota_alumno FOREIGN KEY (id_alumno)
        REFERENCES alumno(id_alumno)
);

INSERT INTO rol(nombre_rol, descripcion) VALUES
('ADMIN', 'Administrador del sistema'),
('PROFESOR', 'Docente del sistema'),
('ESTUDIANTE', 'Alumno del sistema');

INSERT INTO seccion(nombre_seccion, periodo_academico, capacidad_maxima)
VALUES ('A', '2026-II', 35);
