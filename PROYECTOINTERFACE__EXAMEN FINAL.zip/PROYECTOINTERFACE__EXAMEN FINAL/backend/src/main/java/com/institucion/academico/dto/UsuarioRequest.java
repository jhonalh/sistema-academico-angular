package com.institucion.academico.dto;

import jakarta.validation.constraints.*;
import java.util.List;

public record UsuarioRequest(
    @NotBlank(message = "El primer nombre es obligatorio")
    @Pattern(
        regexp = "^[A-Za-zÁÉÍÓÚáéíóúÑñÜü ]{2,100}$",
        message = "El primer nombre solo debe contener letras y espacios"
    )
    String primerNombre,

    @NotBlank(message = "El segundo nombre es obligatorio")
    @Pattern(
        regexp = "^[A-Za-zÁÉÍÓÚáéíóúÑñÜü ]{2,100}$",
        message = "El segundo nombre solo debe contener letras y espacios"
    )
    String segundoNombre,

    @Pattern(
        regexp = "^$|^[A-Za-zÁÉÍÓÚáéíóúÑñÜü ]{2,100}$",
        message = "Los apellidos solo deben contener letras y espacios"
    )
    String apellido,

    @NotBlank(message = "El DNI es obligatorio")
    @Pattern(regexp = "\\d{8}", message = "El DNI debe tener exactamente 8 dígitos")
    String dni,

    @Email(message = "Ingrese un correo electrónico válido")
    @NotBlank(message = "El correo electrónico es obligatorio")
    String email,

    @NotBlank(message = "La contraseña es obligatoria")
    @Pattern(
        regexp = "\\d{6}",
        message = "La contraseña de un usuario nuevo debe tener exactamente 6 dígitos"
    )
    String password,

    @NotBlank(message = "El rol es obligatorio")
    String rol,

    @NotEmpty(message = "Debe registrar al menos un teléfono")
    @Size(max = 2, message = "Solo se permiten hasta 2 teléfonos por usuario")
    List<
        @Pattern(
            regexp = "\\d{9}",
            message = "Cada teléfono debe tener exactamente 9 dígitos"
        ) String
    > telefonos
) {}
