package com.institucion.academico.dto;

public record LoginResponse(
    String token,
    String rol,
    String nombreCompleto
) {}
