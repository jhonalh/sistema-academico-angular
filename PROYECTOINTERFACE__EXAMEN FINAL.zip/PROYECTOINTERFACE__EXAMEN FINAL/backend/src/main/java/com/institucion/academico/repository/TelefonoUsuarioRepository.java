package com.institucion.academico.repository;

import com.institucion.academico.entity.TelefonoUsuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TelefonoUsuarioRepository extends JpaRepository<TelefonoUsuario, Integer> {
    boolean existsByNumero(String numero);
    boolean existsByNumeroAndUsuario_IdNot(String numero, Integer idUsuario);
}
