package com.institucion.academico.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
public class JwtService {
    @Value("${app.jwt.secret}")
    private String secret;

    @Value("${app.jwt.expiration-ms}")
    private long expirationMs;

    private SecretKey key() {
        return Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
    }

    public String generate(String dni, String rol) {
        Date now = new Date();
        return Jwts.builder()
            .subject(dni)
            .claim("role", rol)
            .issuedAt(now)
            .expiration(new Date(now.getTime() + expirationMs))
            .signWith(key())
            .compact();
    }

    private Claims claims(String token) {
        return Jwts.parser()
            .verifyWith(key())
            .build()
            .parseSignedClaims(token)
            .getPayload();
    }

    public String getDni(String token) {
        return claims(token).getSubject();
    }

    public boolean isValid(String token) {
        try {
            Claims c = claims(token);
            return c.getExpiration() != null && c.getExpiration().after(new Date());
        } catch (Exception ex) {
            return false;
        }
    }
}
