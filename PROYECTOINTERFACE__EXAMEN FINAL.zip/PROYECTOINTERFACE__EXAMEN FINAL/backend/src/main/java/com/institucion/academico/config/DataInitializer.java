package com.institucion.academico.config;

import com.institucion.academico.service.AdminInitializerService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initAdmin(AdminInitializerService service) {
        return args -> service.inicializarAdministrador();
    }
}
