package com.institucion.academico.controller;

import com.institucion.academico.entity.Curso;
import com.institucion.academico.repository.CursoRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/cursos")
public class CursoController {

    private final CursoRepository repository;

    public CursoController(CursoRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<Curso> listar() {
        return repository.findAll();
    }

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Curso curso) {
        String validacion = validar(curso);
        if (validacion != null) {
            return ResponseEntity.badRequest().body(Map.of("mensaje", validacion));
        }

        curso.setId(null);
        if (curso.getEstado() == null) {
            curso.setEstado(true);
        }

        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(repository.save(curso));
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizar(
        @PathVariable Integer id,
        @RequestBody Curso cambios
    ) {
        String validacion = validar(cambios);
        if (validacion != null) {
            return ResponseEntity.badRequest().body(Map.of("mensaje", validacion));
        }

        return repository.findById(id)
            .<ResponseEntity<?>>map(curso -> {
                curso.setNombre(cambios.getNombre().trim());
                curso.setDescripcion(
                    cambios.getDescripcion() == null
                        ? ""
                        : cambios.getDescripcion().trim()
                );
                curso.setIdSeccion(cambios.getIdSeccion());
                curso.setEstado(
                    cambios.getEstado() == null
                        ? Boolean.TRUE
                        : cambios.getEstado()
                );

                Curso actualizado = repository.save(curso);
                return ResponseEntity.ok(actualizado);
            })
            .orElseGet(() ->
                ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("mensaje", "El curso no existe"))
            );
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Integer id) {
        if (!repository.existsById(id)) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                .body(Map.of("mensaje", "El curso no existe"));
        }

        repository.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    private String validar(Curso curso) {
        if (curso.getNombre() == null || curso.getNombre().trim().isEmpty()) {
            return "El nombre del curso es obligatorio";
        }

        if (curso.getIdSeccion() == null || curso.getIdSeccion() <= 0) {
            return "La sección debe ser un número mayor que 0";
        }

        return null;
    }
}
