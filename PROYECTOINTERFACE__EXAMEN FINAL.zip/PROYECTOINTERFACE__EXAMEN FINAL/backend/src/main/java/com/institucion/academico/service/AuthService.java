package com.institucion.academico.service;

import com.institucion.academico.dto.*;
import com.institucion.academico.entity.Usuario;
import com.institucion.academico.repository.UsuarioRepository;
import com.institucion.academico.security.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {
    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthService(UsuarioRepository usuarioRepository, PasswordEncoder passwordEncoder, JwtService jwtService) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    public LoginResponse login(LoginRequest req) {
        Usuario u = usuarioRepository.findByDni(req.dni())
            .orElseThrow(() -> new IllegalArgumentException("DNI o contraseña incorrectos"));

        if (!Boolean.TRUE.equals(u.getEstado()) || !passwordEncoder.matches(req.password(), u.getPasswordHash())) {
            throw new IllegalArgumentException("DNI o contraseña incorrectos");
        }

        String token = jwtService.generate(u.getDni(), u.getRol().getNombre());
        return new LoginResponse(
            token,
            u.getRol().getNombre(),
            u.getPrimerNombre() + " " + u.getSegundoNombre() + " " + u.getApellido()
        );
    }
}
