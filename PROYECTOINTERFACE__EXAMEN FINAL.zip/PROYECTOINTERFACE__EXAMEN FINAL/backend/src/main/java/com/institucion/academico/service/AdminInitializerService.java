package com.institucion.academico.service;

import com.institucion.academico.entity.Rol;
import com.institucion.academico.entity.TelefonoUsuario;
import com.institucion.academico.entity.Usuario;
import com.institucion.academico.repository.RolRepository;
import com.institucion.academico.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class AdminInitializerService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;

    public AdminInitializerService(
        UsuarioRepository usuarioRepository,
        RolRepository rolRepository,
        PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public void inicializarAdministrador() {

        // Si ya existe cualquier usuario ADMIN, no se crea otro.
        // Así el administrador predeterminado puede ser editado sin duplicarse al reiniciar.
        if (usuarioRepository.existsByRol_Nombre("ADMIN")) {
            return;
        }

        Rol admin = rolRepository.findByNombre("ADMIN")
            .orElseThrow(() ->
                new IllegalStateException("No existe el rol ADMIN. Ejecuta primero el script SQL.")
            );

        Usuario u = new Usuario();
        u.setDni("76638892");
        u.setPrimerNombre("Admin");
        u.setSegundoNombre("Sistema");
        u.setApellido("");
        u.setEmail("programadorlh@gmail.com");
        u.setPasswordHash(passwordEncoder.encode("admin123"));
        u.setEstado(true);
        u.setRol(admin);

        TelefonoUsuario telefono = new TelefonoUsuario();
        telefono.setNumero("933610705");
        telefono.setUsuario(u);
        u.getTelefonos().add(telefono);

        usuarioRepository.saveAndFlush(u);
    }
}
