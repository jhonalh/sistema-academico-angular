package com.institucion.academico.service;

import com.institucion.academico.dto.UsuarioRequest;
import com.institucion.academico.dto.UsuarioResponse;
import com.institucion.academico.dto.UsuarioUpdateRequest;
import com.institucion.academico.entity.Rol;
import com.institucion.academico.entity.TelefonoUsuario;
import com.institucion.academico.entity.Usuario;
import com.institucion.academico.repository.RolRepository;
import com.institucion.academico.repository.TelefonoUsuarioRepository;
import com.institucion.academico.repository.UsuarioRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final TelefonoUsuarioRepository telefonoRepository;
    private final PasswordEncoder passwordEncoder;

    public UsuarioService(
        UsuarioRepository usuarioRepository,
        RolRepository rolRepository,
        TelefonoUsuarioRepository telefonoRepository,
        PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.telefonoRepository = telefonoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional(readOnly = true)
    public List<UsuarioResponse> listar() {
        return usuarioRepository.findAllByOrderByIdAsc()
            .stream()
            .map(UsuarioResponse::from)
            .toList();
    }

    @Transactional
    public UsuarioResponse crear(UsuarioRequest req) {
        validarCantidadTelefonos(req.telefonos());
        validarDuplicadosNuevo(req.dni(), req.email(), req.telefonos());

        Rol rol = buscarRol(req.rol());

        Usuario u = new Usuario();
        u.setPrimerNombre(req.primerNombre().trim());
        u.setSegundoNombre(req.segundoNombre().trim());
        u.setApellido(req.apellido() == null ? "" : req.apellido().trim());
        u.setDni(req.dni());
        u.setEmail(req.email().trim().toLowerCase());
        u.setPasswordHash(passwordEncoder.encode(req.password()));
        u.setRol(rol);
        u.setEstado(true);

        reemplazarTelefonos(u, req.telefonos());

        Usuario guardado = usuarioRepository.saveAndFlush(u);

        // Vuelve a leer desde MySQL para que la respuesta represente lo realmente persistido.
        return UsuarioResponse.from(
            usuarioRepository.findOneById(guardado.getId())
                .orElseThrow(() -> new IllegalStateException("No se pudo verificar el usuario guardado"))
        );
    }

    @Transactional
    public UsuarioResponse actualizar(Integer id, UsuarioUpdateRequest req) {
        validarCantidadTelefonos(req.telefonos());

        Usuario u = usuarioRepository.findOneById(id)
            .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        if (usuarioRepository.existsByDniAndIdNot(req.dni(), id)) {
            throw new IllegalArgumentException("El DNI ya está registrado y pertenece a otra cuenta");
        }

        String emailNormalizado = req.email().trim().toLowerCase();
        if (usuarioRepository.existsByEmailAndIdNot(emailNormalizado, id)) {
            throw new IllegalArgumentException("El correo electrónico ya está en uso por otra cuenta");
        }

        validarTelefonosSinDuplicados(req.telefonos());
        for (String numero : req.telefonos()) {
            if (telefonoRepository.existsByNumeroAndUsuario_IdNot(numero, id)) {
                throw new IllegalArgumentException("El teléfono " + numero + " ya está registrado en otra cuenta");
            }
        }

        u.setPrimerNombre(req.primerNombre().trim());
        u.setSegundoNombre(req.segundoNombre().trim());
        u.setApellido(req.apellido() == null ? "" : req.apellido().trim());
        u.setDni(req.dni());
        u.setEmail(emailNormalizado);
        u.setRol(buscarRol(req.rol()));

        // Vacío = conservar la contraseña existente.
        if (req.password() != null && !req.password().isBlank()) {
            u.setPasswordHash(passwordEncoder.encode(req.password()));
        }

        // orphanRemoval=true elimina de telefono_usuario los números anteriores.
        // Los nuevos se insertan ligados al mismo id_usuario.
        reemplazarTelefonos(u, req.telefonos());

        usuarioRepository.saveAndFlush(u);

        return UsuarioResponse.from(
            usuarioRepository.findOneById(id)
                .orElseThrow(() -> new IllegalStateException("No se pudo verificar la actualización"))
        );
    }

    @Transactional
    public void eliminar(Integer id) {
        Usuario u = usuarioRepository.findOneById(id)
            .orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));

        // Por cascade/orphanRemoval + ON DELETE CASCADE desaparecen también sus teléfonos.
        usuarioRepository.delete(u);
        usuarioRepository.flush();
    }

    private Rol buscarRol(String rol) {
        return rolRepository.findByNombre(rol.trim().toUpperCase())
            .orElseThrow(() -> new IllegalArgumentException("Rol inválido"));
    }

    private void reemplazarTelefonos(Usuario u, List<String> telefonos) {
        u.getTelefonos().clear();

        for (String numero : telefonos) {
            TelefonoUsuario t = new TelefonoUsuario();
            t.setNumero(numero);
            t.setUsuario(u);
            u.getTelefonos().add(t);
        }
    }

    private void validarDuplicadosNuevo(String dni, String email, List<String> telefonos) {
        if (usuarioRepository.existsByDni(dni)) {
            throw new IllegalArgumentException("El DNI ya está registrado y pertenece a otra cuenta");
        }

        String emailNormalizado = email.trim().toLowerCase();
        if (usuarioRepository.existsByEmail(emailNormalizado)) {
            throw new IllegalArgumentException("El correo electrónico ya está en uso por otra cuenta");
        }

        validarTelefonosSinDuplicados(telefonos);

        for (String numero : telefonos) {
            if (telefonoRepository.existsByNumero(numero)) {
                throw new IllegalArgumentException("El teléfono " + numero + " ya está registrado en otra cuenta");
            }
        }
    }

    private void validarTelefonosSinDuplicados(List<String> telefonos) {
        Set<String> unicos = new HashSet<>(telefonos);

        if (unicos.size() != telefonos.size()) {
            throw new IllegalArgumentException("No puedes registrar el mismo teléfono más de una vez");
        }
    }

    private void validarCantidadTelefonos(List<String> telefonos) {
        if (telefonos == null || telefonos.isEmpty()) {
            throw new IllegalArgumentException("Debe registrar al menos un teléfono");
        }

        if (telefonos.size() > 2) {
            throw new IllegalArgumentException("Solo se permiten hasta 2 teléfonos por usuario");
        }
    }
}
