package com.institucion.academico.repository;

import com.institucion.academico.entity.Usuario;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Integer> {

    Optional<Usuario> findByDni(String dni);

    boolean existsByDni(String dni);
    boolean existsByEmail(String email);
    boolean existsByDniAndIdNot(String dni, Integer id);
    boolean existsByEmailAndIdNot(String email, Integer id);

    boolean existsByRol_Nombre(String nombreRol);

    @EntityGraph(attributePaths = {"rol", "telefonos"})
    List<Usuario> findAllByOrderByIdAsc();

    @EntityGraph(attributePaths = {"rol", "telefonos"})
    Optional<Usuario> findOneById(Integer id);
}
