package com.institucion.academico.dto;

import com.institucion.academico.entity.Usuario;
import java.util.List;

public record UsuarioResponse(
    Integer id,
    String dni,
    String primerNombre,
    String segundoNombre,
    String apellido,
    String email,
    Boolean estado,
    String rol,
    List<String> telefonos
) {
    public static UsuarioResponse from(Usuario u) {
        return new UsuarioResponse(
            u.getId(),
            u.getDni(),
            u.getPrimerNombre(),
            u.getSegundoNombre(),
            u.getApellido(),
            u.getEmail(),
            u.getEstado(),
            u.getRol().getNombre(),
            u.getTelefonos().stream().map(t -> t.getNumero()).toList()
        );
    }
}
