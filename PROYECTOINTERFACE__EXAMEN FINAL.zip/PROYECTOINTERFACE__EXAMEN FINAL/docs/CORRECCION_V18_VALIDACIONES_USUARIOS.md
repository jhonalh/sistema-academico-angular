# Corrección v18 — Validaciones de usuarios

Se agregaron validaciones en Angular y Spring Boot.

## Nombres
- Primer nombre obligatorio.
- Segundo nombre obligatorio.
- Solo letras, espacios y caracteres españoles.
- No se aceptan números ni símbolos.

## DNI
- Exactamente 8 dígitos.
- No puede repetirse.
- Si ya existe se muestra:
  `El DNI ya está registrado. Usa un DNI diferente.`

## Correo
- Debe tener formato válido.
- Se compara sin distinguir mayúsculas/minúsculas.
- No puede repetirse.
- Si ya existe se muestra:
  `El correo electrónico ya está en uso. Usa otro correo.`

## Teléfonos
- Entre 1 y 2 teléfonos.
- Exactamente 9 dígitos cada uno.
- No puede repetirse el mismo teléfono dentro del usuario.
- Tampoco puede usarse un teléfono registrado por otra cuenta.

## Contraseña
- Usuario nuevo: exactamente 6 dígitos.
- En edición no se muestra la contraseña actual.
- Si el campo queda vacío al editar, se conserva la contraseña anterior.

Las reglas están duplicadas en frontend y backend para evitar que se salten
las validaciones enviando peticiones directamente a la API.
