# Guía para el PDF de presentación técnica

## 1. Problema
La institución educativa realizaba procesos manuales y no tenía control de acceso por roles. La solución centraliza usuarios y cursos en una SPA.

## 2. Arquitectura
Angular SPA -> API REST Spring Boot -> MySQL.

## 3. Rutas
Pública:
- `/login`

Protegidas:
- `/admin/dashboard`
- `/admin/usuarios`
- `/admin/cursos`
- `/profesor/dashboard`
- `/estudiante/dashboard`

La aplicación usa `loadComponent` para carga dinámica.

## 4. Guards
### AuthGuard
Valida que exista un JWT y que no esté expirado.

### RoleGuard
Autoriza únicamente los roles configurados en cada rama de rutas.

## 5. JWT
1. Angular envía DNI + contraseña.
2. Spring Boot valida las credenciales.
3. Si son correctas, devuelve un JWT.
4. Angular almacena token, rol y nombre.
5. El interceptor agrega `Authorization: Bearer <token>`.
6. Spring Security valida el JWT.
7. Un `401` provoca cierre automático de sesión.

## 6. Servicios REST
Usuarios:
- GET `/api/usuarios`
- POST `/api/usuarios`
- PUT `/api/usuarios/{id}`
- DELETE `/api/usuarios/{id}`

Cursos:
- GET `/api/cursos`
- POST `/api/cursos`
- PUT `/api/cursos/{id}`
- DELETE `/api/cursos/{id}`

## 7. Validaciones
- DNI: 8 dígitos.
- DNI único.
- Correo único.
- Dos nombres obligatorios.
- Contraseña de 6 dígitos.
- Múltiples teléfonos.
- Teléfono de 9 dígitos.
- Teléfonos almacenados en `telefono_usuario`.

## 8. Pruebas funcionales
Tomar captura de cada caso:

1. Login correcto con ADMIN.
2. Login incorrecto.
3. Acceso sin JWT a `/admin/usuarios`.
4. ESTUDIANTE intentando ingresar a una ruta de ADMIN.
5. DNI de 7 dígitos.
6. DNI de 9 dígitos.
7. DNI ya existente.
8. Correo ya existente.
9. Contraseña con longitud incorrecta.
10. Teléfono de 10 dígitos.
11. Dos teléfonos válidos en un usuario.
12. Verificar los dos teléfonos en `telefono_usuario` desde Workbench.
13. Crear usuario.
14. Editar usuario.
15. Eliminar usuario.
16. Crear curso.
17. Editar curso.
18. Eliminar curso.
19. Cerrar sesión.
20. Presionar Atrás y comprobar que no se recupera una vista privada.

## 9. GitHub
Agregar el enlace real del repositorio del grupo.

## 10. README
Mostrar las instrucciones de instalación y ejecución incluidas en `README.md`.

## 11. Conclusión
Explicar cómo JWT, guards, roles, SPA y REST mejoraron la seguridad y centralizaron la administración.
