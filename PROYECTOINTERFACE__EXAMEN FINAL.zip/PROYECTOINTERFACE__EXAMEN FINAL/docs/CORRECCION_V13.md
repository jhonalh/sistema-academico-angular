# Corrección v13

Se corrigió el error:

`LazyInitializationException: failed to lazily initialize a collection ... Usuario.telefonos`

La inicialización/migración del administrador se ejecuta ahora dentro de un método `@Transactional`.

Resultado esperado al ejecutar:

```text
npm start
```

Backend:
```text
Tomcat started on port 8080
Started AcademicoApplication
```

Frontend:
```text
Application bundle generation complete.
Local: http://localhost:4200/
```

Administrador:
- DNI: 76638892
- Contraseña: admin123
- Nombre: Admin Sistema
- Correo: programadorlh@gmail.com
- Teléfono: 933610705
