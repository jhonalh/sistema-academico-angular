# Corrección v16 — Persistencia real de Usuarios

Se revisó el CRUD de usuarios para asegurar persistencia real en MySQL.

## Crear
`POST /api/usuarios`
- Inserta una fila en `usuario`.
- Inserta 1 o 2 filas en `telefono_usuario`.
- La contraseña se guarda cifrada con BCrypt.
- Después de guardar, el frontend vuelve a consultar la API.

## Editar
`PUT /api/usuarios/{id}`
- Actualiza nombre, DNI, correo y rol en `usuario`.
- Si contraseña queda vacía, conserva el hash actual.
- Si se escribe una contraseña nueva, se vuelve a cifrar.
- Reemplaza los teléfonos asociados en `telefono_usuario`.
- Al finalizar, el backend vuelve a leer el usuario desde MySQL y devuelve esos datos.
- El frontend recarga la lista desde la API.

## Eliminar
`DELETE /api/usuarios/{id}`
- Elimina el usuario.
- Sus teléfonos se eliminan por la relación en cascada.
- El frontend vuelve a consultar la API para verificar el resultado.

## Administrador predeterminado
Solo se crea si no existe ningún usuario con rol `ADMIN`.
Esto evita que aparezca un administrador duplicado si el administrador original fue editado.

## Verificación
Ejecutar:
`database/verificar_crud_usuarios.sql`
