# Configuración local

## MySQL Workbench
- Host: `127.0.0.1`
- Puerto: `3306`
- Usuario: `root`
- Contraseña configurada: `789456`
- Base de datos: `sistema_academico`

## Acceso inicial a la aplicación
- DNI: `12345678`
- Contraseña: `123456`

La contraseña de MySQL y la contraseña de acceso a la aplicación son diferentes.
